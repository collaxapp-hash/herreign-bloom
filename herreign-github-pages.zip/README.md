# HerReign Pilates

嘉兰百合绽放页面。进入页面后短暂停留，自动播放花开动画并呈现文字；双击页面可重新播放。

## GitHub Pages 发布

将本目录内的文件和 assets 文件夹上传至仓库根目录。

在 Settings → Pages 中选择：

- Source: Deploy from a branch
- Branch: main
- Folder: / (root)

点击 Save，等待 GitHub Pages 部署完成。页面资源使用相对路径，可用于仓库子路径。

字体许可见 assets/fonts/OFL.txt。
