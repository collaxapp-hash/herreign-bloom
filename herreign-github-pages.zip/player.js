(() => {
  'use strict';
  const stage = document.querySelector('.flower-stage');
  const video = document.querySelector('.bloom-video');
  const status = document.querySelector('[role="status"]');
  const copyGroups = document.querySelectorAll('.copy-group');
  const OPENING_HOLD_MS = 400;
  // Start the copy as the petals settle, while the video still has time to run.
  const COPY_CUE_SECONDS = 3.85;
  let state = 'holding';
  let copyVisible = false;
  let frameRequest = null;
  let paintRequest = null;
  let startTimer = null;
  let playAttempt = 0;

  const messages = {
    holding: '花朵准备绽放。',
    ready: '花朵准备绽放，轻触页面即可播放。',
    starting: '花朵准备绽放。',
    playing: '花朵正在绽放。',
    ended: '花朵已盛开，双击页面可重新播放。',
    error: '视频暂时无法播放，可双击页面重试。',
  };

  function setState(next) {
    if (state === next && stage.dataset.state === next) return;
    state = next;
    stage.dataset.state = next;
    status.textContent = messages[next];
  }

  function setCopy(visible) {
    if (copyVisible === visible) return;
    copyVisible = visible;
    stage.dataset.copy = visible ? 'visible' : 'hidden';
    copyGroups.forEach(group => group.setAttribute('aria-hidden', String(!visible)));
  }

  function syncCopy(time = video.currentTime) {
    setCopy(state !== 'holding' && state !== 'ready' && time >= COPY_CUE_SECONDS);
  }

  function stopFrameWatch() {
    if (frameRequest !== null) video.cancelVideoFrameCallback(frameRequest);
    frameRequest = null;
  }

  function watchFrame() {
    if (!video.requestVideoFrameCallback || frameRequest !== null) return;
    frameRequest = video.requestVideoFrameCallback((_, frame) => {
      frameRequest = null;
      syncCopy(frame.mediaTime);
      if (!video.paused && !video.ended) watchFrame();
    });
  }

  function cancelOpeningWait() {
    if (startTimer !== null) clearTimeout(startTimer);
    if (paintRequest !== null) cancelAnimationFrame(paintRequest);
    startTimer = null;
    paintRequest = null;
  }

  async function play(attempt = playAttempt) {
    if (attempt !== playAttempt || !['holding', 'ready'].includes(state)) return;
    stopFrameWatch();
    setState('starting');
    video.muted = true;
    try {
      await video.play();
    } catch (error) {
      if (attempt !== playAttempt) return;
      setState(video.error || error.name === 'NotSupportedError' ? 'error' : 'ready');
    }
  }

  function queueOpening() {
    if (state !== 'holding' || video.readyState < 2 || video.seeking || startTimer !== null || paintRequest !== null) return;
    const attempt = playAttempt;
    // Paint the opening frame before counting the brief still moment.
    paintRequest = requestAnimationFrame(() => {
      paintRequest = requestAnimationFrame(() => {
        paintRequest = null;
        if (attempt !== playAttempt || state !== 'holding') return;
        startTimer = setTimeout(() => {
          startTimer = null;
          play(attempt);
        }, OPENING_HOLD_MS);
      });
    });
  }

  function beginOpening() {
    ++playAttempt;
    cancelOpeningWait();
    stopFrameWatch();
    video.pause();
    setCopy(false);
    setState('holding');
    if (video.error) {
      video.load();
    } else if (video.readyState > 0 && video.currentTime !== 0) {
      video.currentTime = 0;
    }
    queueOpening();
  }

  video.muted = true;
  video.defaultMuted = true;
  video.addEventListener('loadeddata', queueOpening);
  video.addEventListener('canplay', queueOpening);
  video.addEventListener('playing', () => {
    if (video.paused) return;
    setState('playing');
    syncCopy();
    watchFrame();
  });
  video.addEventListener('timeupdate', () => syncCopy());
  video.addEventListener('seeked', () => {
    syncCopy();
    queueOpening();
  });
  video.addEventListener('pause', stopFrameWatch);
  video.addEventListener('ended', () => {
    if (!video.ended || state === 'holding') return;
    stopFrameWatch();
    setCopy(true);
    setState('ended');
    // Keep this exact decoded frame. Never swap video for an RGB still image.
  });
  video.addEventListener('error', () => {
    cancelOpeningWait();
    stopFrameWatch();
    setState('error');
  });
  // Some browsers require a gesture even for muted video. Keep the page free
  // of controls and retry on the first interaction only when playback is blocked.
  function retryBlockedPlayback() {
    if (state === 'ready') play();
  }
  document.addEventListener('pointerdown', retryBlockedPlayback, { passive: true });
  document.addEventListener('keydown', retryBlockedPlayback);
  document.addEventListener('dblclick', beginOpening);

  beginOpening();
})();
